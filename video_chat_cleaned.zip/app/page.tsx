"use client"

import type React from "react"
import { useEffect, useRef, useState } from "react"
import type { IAgoraRTCClient, IAgoraRTCRemoteUser } from "agora-rtc-sdk-ng"
import type { ChatClient } from "agora-chat"
import {
  Loader2,
  Crown,
  Menu,
  Users,
  Users2,
  UserIcon as Female,
  UserIcon as Male,
  ChevronDown,
  SkipForward,
  Music,
  ChevronUp,
  Sparkles,
  MessageSquare,
  Compass,
  Gamepad2,
  Film,
  Trophy,
  Cpu,
  Palette,
  Heart,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"
import Image from "next/image"
import { useMobile } from "@/hooks/use-mobile"
import { EmojiPicker } from "@/components/emoji-picker"
import { COUNTRIES, SAMPLE_TRACKS } from "@/lib/constants"
import { CameraView } from "@/components/camera-view"
import { InterestSelector, type Interest } from "@/components/interest-selector"
import { LobbyRoom } from "@/components/lobby-room"
import {
  createClient,
  createChatClient,
  createLocalTracks,
  sendChatMessage,
  leaveChannel,
  logoutFromChat,
  subscribeToUser,
  type LocalTracks,
} from "@/lib/agora-client"
import { UserProfileCard } from "@/components/user-profile-card"
import type { UserReputation, UserCommendation } from "@/types/user-types"
import { ReputationDisplay } from "@/components/reputation-display"
import { CommendationNotification } from "@/components/commendation-notification"
import { ThumbsAnimation } from "@/components/thumbs-animation"
import { VideoOverlayActions } from "@/components/video-overlay-actions"
import { FriendsListModal } from "@/components/friends-list-modal"
import { MusicPlayerModal } from "@/components/music-player-modal"
import { CountrySelectorModal } from "@/components/country-selector-modal"
import { DatingListModal } from "@/components/dating-list-modal"
import { Sidebar } from "@/components/sidebar"
import { VipPopup } from "@/components/vip-popup"
import { DatingModeOverlay } from "@/components/dating-mode-overlay"
// Import the DatingThemeProvider at the top of the file
import { DatingThemeProvider } from "@/components/dating-theme-provider"

type Message = {
  id: string
  text: string
  sender: "me" | "stranger"
  timestamp: Date
  username?: string
  isMusic?: boolean
  isEmoji?: boolean
  isMeme?: boolean
  isImage?: boolean
  musicData?: {
    title: string
    artist: string
    albumArt?: string
  }
  memeUrl?: string
  imageUrl?: string
}

// Update the User type to include reputation
type UserType = {
  username: string
  email?: string
  instagram?: string
  snapchat?: string
  facebook?: string
  discord?: string
  isLoggedIn: boolean
  profileImage?: string
  country?: string
  countryFlag?: string
  countryName?: string
  isVIP?: boolean
  subscriptionDate?: string
  reputation?: UserReputation
}

type Friend = {
  id: string
  name: string
  online: boolean
}

type FriendRequest = {
  id: string
  name: string
}

type Gender = "male" | "female" | "any"

type ChatNotificationType = {
  id: string
  message: string
  sender: string
}

// Dating match type
type DatingMatch = {
  id: string
  name: string
  profileImage?: string
  country?: string
  countryFlag?: string
  matchDate: string
  lastMessage?: string
  online: boolean
}

export default function ChatChill() {
  const isMobile = useMobile()
  const [isConnected, setIsConnected] = useState(false)
  const [isConnecting, setIsConnecting] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [videoEnabled, setVideoEnabled] = useState(true)
  const [audioEnabled, setAudioEnabled] = useState(true)
  const [peopleSkipped, setPeopleSkipped] = useState(0)
  const [messages, setMessages] = useState<Message[]>([])
  const [messageInput, setMessageInput] = useState("")
  const [selectedCountry, setSelectedCountry] = useState(COUNTRIES[0])
  const [user, setUser] = useState<UserType | null>(null)
  const [strangerUsername, setStrangerUsername] = useState("Stranger")
  const [strangerCountry, setStrangerCountry] = useState(COUNTRIES[0])
  const [channelName, setChannelName] = useState("")
  const [userId, setUserId] = useState<number>(0)
  const [friends, setFriends] = useState<Friend[]>([])
  const [showFriends, setShowFriends] = useState(false)
  const [inviteFriendId, setInviteFriendId] = useState<string | null>(null)
  const [isPlayingMusic, setIsPlayingMusic] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const [showMusicPanel, setShowMusicPanel] = useState(false)
  const [currentTrack, setCurrentTrack] = useState<(typeof SAMPLE_TRACKS)[0] | null>(null)
  const [isAudioPlaying, setIsAudioPlaying] = useState(false)
  const [myVolume, setMyVolume] = useState(80)
  const [strangerVolume, setStrangerVolume] = useState(80)
  const [microphoneVolume, setMicrophoneVolume] = useState(80)
  const [speakerVolume, setSpeakerVolume] = useState(80)
  const [onlineUsers, setOnlineUsers] = useState(Math.floor(Math.random() * 4000) + 500)
  const [selectedGender, setSelectedGender] = useState<Gender>("any")
  const [showWaitingScreen, setShowWaitingScreen] = useState(true)
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [debugLogs, setDebugLogs] = useState<string[]>([])
  const [spotifyConnected, setSpotifyConnected] = useState(false)
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false)
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false)
  const [pendingFriendRequest, setPendingFriendRequest] = useState<FriendRequest | null>(null)
  const [showChat, setShowChat] = useState(true) // Default to true for desktop, will be set based on mobile in useEffect
  const [isVipPopupOpen, setIsVipPopupOpen] = useState(false)
  const [isInCall, setIsInCall] = useState(false)
  const [hasStrangerVideo, setHasStrangerVideo] = useState(false)
  const [showTooltips, setShowTooltips] = useState(true)
  const [isSearchingForStranger, setIsSearchingForStranger] = useState(false)
  const [chatNotifications, setChatNotifications] = useState<ChatNotificationType[]>([])
  const [spotifyToken, setSpotifyToken] = useState<string | null>(null)
  const [spotifySearchQuery, setSpotifySearchQuery] = useState("")
  const [spotifySearchResults, setSpotifySearchResults] = useState<any[]>([])
  const [spotifyPlaylists, setSpotifyPlaylists] = useState<any[]>([])
  const [freeSongsRemaining, setFreeSongsRemaining] = useState(5)
  const [spotifyPanelOpen, setSpotifyPanelOpen] = useState(false)
  const [isVideoOn, setIsVideoOn] = useState(true)
  const [isAudioOn, setIsAudioOn] = useState(true)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [musicUsageCount, setMusicUsageCount] = useState(0)
  const [isVip, setIsVip] = useState(false)
  const [showMusicPlayer, setShowMusicPlayer] = useState(false)
  const [showFriendsList, setShowFriendsList] = useState(false)
  const [showCountrySelector, setShowCountrySelector] = useState(false)
  const [showDatingList, setShowDatingList] = useState(false)
  const [agoraClient, setAgoraClient] = useState<IAgoraRTCClient | null>(null)
  const [chatClient, setChatClient] = useState<ChatClient | null>(null)
  const [localTracks, setLocalTracks] = useState<LocalTracks>({ videoTrack: null, audioTrack: null })
  const [remoteUsers, setRemoteUsers] = useState<IAgoraRTCRemoteUser[]>([])
  const [chatGroupId, setChatGroupId] = useState<string | null>(null)
  const [notifications, setNotifications] = useState<
    Array<{ id: string; type: "commend" | "kick" | "received-commend" | "super-like"; message: string }>
  >([])
  const [showThumbsUp, setShowThumbsUp] = useState(false)
  const [showThumbsDown, setShowThumbsDown] = useState(false)
  const [showHeartAnimation, setShowHeartAnimation] = useState(false)
  const [freeSuperLikes, setFreeSuperLikes] = useState(2) // Start with 2 free super likes
  const [datingMatches, setDatingMatches] = useState<DatingMatch[]>([])

  // Interest and lobby system states
  const [showInterestSelector, setShowInterestSelector] = useState(false)
  const [selectedInterest, setSelectedInterest] = useState<Interest | null>(null)
  const [showLobby, setShowLobby] = useState(false)
  const [currentLobby, setCurrentLobby] = useState<string>("General")

  const videoRef = useRef<HTMLVideoElement>(null)

  const audioRef = useRef<HTMLAudioElement | null>(null)
  const chatContainerRef = useRef<HTMLDivElement | null>(null)
  const searchTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const friendsListRef = useRef<HTMLDivElement | null>(null)
  const mainRef = useRef<HTMLDivElement>(null)

  const [showUserProfile, setShowUserProfile] = useState(false)
  const [strangerReputation, setStrangerReputation] = useState<UserReputation>({
    level: Math.floor(Math.random() * 5) + 1,
    points: Math.floor(Math.random() * 500) + 25,
    positiveRatings: Math.floor(Math.random() * 50) + 5,
    negativeRatings: Math.floor(Math.random() * 5),
    badges: [],
    interestGroupBans: [],
  })
  const [userReputation, setUserReputation] = useState<UserReputation>({
    level: 1,
    points: 25,
    positiveRatings: 5,
    negativeRatings: 0,
    badges: [],
    interestGroupBans: [],
  })

  // Set showChat based on mobile status
  useEffect(() => {
    if (isMobile) {
      setShowChat(false)
    }
  }, [isMobile])

  // Add debug log
  const addDebugLog = (message: string) => {
    console.log(message) // Also log to console for easier debugging
    setDebugLogs((prev) => [...prev, `${new Date().toISOString().slice(11, 19)} - ${message}`])
  }

  // Clear debug logs
  const clearDebugLogs = () => {
    setDebugLogs([])
  }

  // Check if user is logged in
  useEffect(() => {
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser)
      // Initialize reputation if not present
      if (!parsedUser.reputation) {
        parsedUser.reputation = userReputation
      }
      setUser(parsedUser)
      setIsLoggedIn(true)
      setUserReputation(parsedUser.reputation || userReputation)
      if (parsedUser.isVIP) {
        setIsVip(true)
      }
    }

    // Load friends
    const storedFriends = localStorage.getItem("friends")
    if (storedFriends) {
      setFriends(JSON.parse(storedFriends))
    } else {
      // Default friends for demo
      const defaultFriends = [
        { id: "1", name: "Alex123", online: true },
        { id: "2", name: "Jordan456", online: false },
        { id: "3", name: "Taylor789", online: true },
        { id: "4", name: "Riley42", online: true },
      ]
      setFriends(defaultFriends)
      localStorage.setItem("friends", JSON.stringify(defaultFriends))
    }

    // Load dating matches
    const storedMatches = localStorage.getItem("datingMatches")
    if (storedMatches) {
      setDatingMatches(JSON.parse(storedMatches))
    } else {
      // Default dating matches for demo
      const defaultMatches: DatingMatch[] = [
        {
          id: "dm1",
          name: "Jamie",
          country: "US",
          countryFlag: "🇺🇸",
          matchDate: new Date(Date.now() - 86400000 * 2).toISOString(), // 2 days ago
          lastMessage: "Hey, how are you?",
          online: true,
        },
        {
          id: "dm2",
          name: "Taylor",
          country: "CA",
          countryFlag: "🇨🇦",
          matchDate: new Date(Date.now() - 86400000 * 5).toISOString(), // 5 days ago
          lastMessage: "Would love to chat again sometime!",
          online: false,
        },
      ]
      setDatingMatches(defaultMatches)
      localStorage.setItem("datingMatches", JSON.stringify(defaultMatches))
    }

    // Load free super likes
    const storedSuperLikes = localStorage.getItem("freeSuperLikes")
    if (storedSuperLikes) {
      setFreeSuperLikes(Number.parseInt(storedSuperLikes, 10))
    } else {
      // Default to 2 free super likes
      localStorage.setItem("freeSuperLikes", "2")
    }

    // Create audio element for music
    audioRef.current = new Audio()
    audioRef.current.addEventListener("ended", () => {
      // Play next track when current one ends
      playNextTrack()
    })

    // Simulate online users count increasing
    const interval = setInterval(() => {
      setOnlineUsers((prev) => {
        const change = Math.floor(Math.random() * 10) - 3
        const newValue = prev + change
        // Keep between 500 and 4500
        return Math.max(500, Math.min(4500, newValue))
      })
    }, 5000)

    // Hide tooltips after 10 seconds
    const tooltipTimer = setTimeout(() => {
      setShowTooltips(false)
    }, 10000)

    // Generate a random user ID for this session
    const newUserId = Math.floor(Math.random() * 100000)
    setUserId(newUserId)

    // Simulate initial loading
    setTimeout(() => {
      setIsLoading(false)
      // Show interest selector after loading
      setShowInterestSelector(true)
    }, 1000)

    // Check VIP status
    const savedVipState = localStorage.getItem("isVip")
    if (savedVipState === "true") {
      setIsVip(true)
    }

    // Check if user has a previously selected interest
    const savedInterest = localStorage.getItem("selectedInterest")
    if (savedInterest) {
      setSelectedInterest(JSON.parse(savedInterest))
      setCurrentLobby(JSON.parse(savedInterest).name)
    }

    // Reset music usage count at midnight
    const now = new Date()
    const lastReset = localStorage.getItem("lastMusicReset")
    if (!lastReset || new Date(lastReset).getDate() !== now.getDate()) {
      localStorage.setItem("musicUsageCount", "0")
      localStorage.setItem("lastMusicReset", now.toString())
      setMusicUsageCount(0)

      // Reset free super likes daily
      if (!isVip) {
        setFreeSuperLikes(2)
        localStorage.setItem("freeSuperLikes", "2")
      }
    } else {
      const savedCount = localStorage.getItem("musicUsageCount")
      if (savedCount) {
        setMusicUsageCount(Number.parseInt(savedCount, 10))
      }
    }

    // Check if we need to reset the free songs counter
    const resetDate = localStorage.getItem("freeSongsResetDate")
    if (resetDate) {
      const lastReset = new Date(resetDate)
      const now = new Date()

      // Reset if it's a new day
      if (
        lastReset.getDate() !== now.getDate() ||
        lastReset.getMonth() !== now.getMonth() ||
        lastReset.getFullYear() !== now.getFullYear()
      ) {
        setFreeSongsRemaining(5)
        localStorage.setItem("freeSongsRemaining", "5")
        localStorage.setItem("freeSongsResetDate", now.toISOString())
      } else {
        // Load saved count
        const savedCount = localStorage.getItem("freeSongsRemaining")
        if (savedCount) {
          setFreeSongsRemaining(Number.parseInt(savedCount))
        }
      }
    } else {
      // First time user
      setFreeSongsRemaining(5)
      localStorage.setItem("freeSongsRemaining", "5")
      localStorage.setItem("freeSongsResetDate", new Date().toISOString())
    }

    const initAgoraClients = async () => {
      try {
        // Initialize RTC client
        const rtcClient = await createClient()
        setAgoraClient(rtcClient)

        // Initialize Chat client
        const chatClientInstance = await createChatClient()
        setChatClient(chatClientInstance)

        // Create local tracks
        const tracks = await createLocalTracks()
        setLocalTracks(tracks)

        // Set up event listeners for RTC client
        if (rtcClient) {
          // Handle user joined event
          rtcClient.on("user-joined", (user) => {
            console.log("User joined:", user.uid)
            setRemoteUsers((prevUsers) => [...prevUsers.filter((u) => u.uid !== user.uid), user])
          })

          // Handle user left event
          rtcClient.on("user-left", (user) => {
            console.log("User left:", user.uid)
            setRemoteUsers((prevUsers) => prevUsers.filter((u) => u.uid !== user.uid))
          })

          // Handle user published event
          rtcClient.on("user-published", async (user, mediaType) => {
            console.log("User published:", user.uid, mediaType)
            await subscribeToUser(rtcClient, user, mediaType)
            setRemoteUsers((prevUsers) => [...prevUsers.filter((u) => u.uid !== user.uid), user])
          })
        }

        // Set up event listeners for Chat client
        if (chatClientInstance) {
          // Handle text message received event
          chatClientInstance.on("message", (message) => {
            console.log("Message received:", message)
            if (message.type === "txt") {
              // Add the message to your chat
              addMessage(message.msg, "stranger", message.from)
            }
          })
        }
      } catch (error) {
        console.error("Error initializing Agora clients:", error)
        setErrorMessage("Failed to initialize video chat. Please try again.")
      }
    }

    initAgoraClients()

    // Clean up on unmount
    return () => {
      const cleanup = async () => {
        if (agoraClient) {
          await leaveChannel(agoraClient, localTracks)
        }
        if (chatClient) {
          await logoutFromChat(chatClient)
        }
      }
      cleanup()
      if (audioRef.current) {
        audioRef.current.pause()
        audioRef.current.src = ""
      }
      clearInterval(interval)
      clearTimeout(tooltipTimer)
      if (searchTimeoutRef.current) {
        clearTimeout(searchTimeoutRef.current)
      }
    }
  }, [])

  // Handle clicks outside the friends list to close it
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (friendsListRef.current && !friendsListRef.current.contains(event.target as Node)) {
        setShowFriends(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  // Apply volume changes to audio elements
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = myVolume / 100
    }
  }, [myVolume])

  // Scroll to bottom of chat when messages change
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight
    }
  }, [messages])

  // Set country from user profile if available
  useEffect(() => {
    if (user?.country) {
      const userCountry = COUNTRIES.find((c) => c.code === user.country)
      if (userCountry) {
        setSelectedCountry(userCountry)
      }
    }
  }, [user])

  // Save login state to localStorage when it changes
  useEffect(() => {
    localStorage.setItem("isLoggedIn", isLoggedIn.toString())
    localStorage.setItem("isVip", isVip.toString())
  }, [isLoggedIn, isVip])

  // Save selected interest to localStorage when it changes
  useEffect(() => {
    if (selectedInterest) {
      localStorage.setItem("selectedInterest", JSON.stringify(selectedInterest))
      setCurrentLobby(selectedInterest.name)
    }
  }, [selectedInterest])

  // Save music usage count to localStorage when it changes
  useEffect(() => {
    localStorage.setItem("musicUsageCount", musicUsageCount.toString())
  }, [musicUsageCount])

  // Save free super likes count to localStorage when it changes
  useEffect(() => {
    localStorage.setItem("freeSuperLikes", freeSuperLikes.toString())
  }, [freeSuperLikes])

  // Save dating matches to localStorage when they change
  useEffect(() => {
    localStorage.setItem("datingMatches", JSON.stringify(datingMatches))
  }, [datingMatches])

  // Handle interest selection
  const handleInterestSelect = (interest: Interest) => {
    setSelectedInterest(interest)
    setShowInterestSelector(false)
    setCurrentLobby(interest.name)
    addDebugLog(`Selected interest: ${interest.name}`)

    // Start searching immediately
    handleStartChat()
  }

  const addNotification = (type: "commend" | "kick" | "received-commend" | "super-like", message: string) => {
    const newNotification = {
      id: Date.now().toString(),
      type,
      message,
    }
    setNotifications((prev) => [...prev, newNotification])

    // Simulate receiving commendations occasionally
    if (type === "commend" && Math.random() > 0.7) {
      setTimeout(() => {
        addNotification("received-commend", "Someone commended you as 'Friendly'!")
      }, 5000)
    }
  }

  const removeNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id))
  }

  // Handle using a free super like
  const handleUseFreeSuper = () => {
    if (freeSuperLikes > 0) {
      setFreeSuperLikes((prev) => prev - 1)
    }
  }

  // Handle super like
  const handleSuperLike = (username: string) => {
    // Show heart animation
    setShowHeartAnimation(true)
    setTimeout(() => setShowHeartAnimation(false), 2000)

    // Add notification
    addNotification("super-like", `You sent a Super Like to ${username}!`)

    // Add message to chat
    addMessage(`You sent a Super Like to ${username}!`, "stranger", "System")

    // Add to dating matches (50% chance of match)
    if (Math.random() > 0.5) {
      setTimeout(() => {
        addNotification("super-like", `${username} liked you back! It's a match!`)
        addMessage(`${username} liked you back! It's a match!`, "stranger", "System")

        // Add to dating matches
        const newMatch: DatingMatch = {
          id: `dm-${Date.now()}`,
          name: username,
          country: strangerCountry.code,
          countryFlag: strangerCountry.flag,
          matchDate: new Date().toISOString(),
          online: true,
        }

        setDatingMatches((prev) => [newMatch, ...prev])
      }, 3000)
    }
  }

  // Handle direct thumbs up from video overlay
  const handleDirectThumbsUp = () => {
    // Show thumbs up animation
    setShowThumbsUp(true)
    setTimeout(() => setShowThumbsUp(false), 2000)

    // Update stranger reputation
    setStrangerReputation((prev) => ({
      ...prev,
      points: prev.points + 10,
      positiveRatings: prev.positiveRatings + 1,
    }))

    // Show a notification
    addNotification("commend", `You gave ${strangerUsername} a thumbs up!`)

    // Show a message in the chat
    addMessage(`You gave ${strangerUsername} a thumbs up!`, "stranger", "System")
  }

  // Handle direct thumbs down from video overlay
  const handleDirectThumbsDown = () => {
    // Show thumbs down animation
    setShowThumbsDown(true)
    setTimeout(() => setShowThumbsDown(false), 2000)

    // Update stranger reputation
    setStrangerReputation((prev) => ({
      ...prev,
      negativeRatings: prev.negativeRatings + 1,
    }))

    // Show a notification
    addNotification("kick", `You gave ${strangerUsername} a thumbs down.`)

    // Show a message in the chat
    addMessage(`You gave ${strangerUsername} a thumbs down. Our moderators will review this.`, "stranger", "System")

    // Skip to next person after a short delay
    setTimeout(() => {
      skipToNext()
    }, 1500)
  }

  // Handle commendation
  const handleCommendation = (commendation: Omit<UserCommendation, "id" | "timestamp">) => {
    console.log("User commended:", commendation)

    // Show thumbs up animation
    setShowThumbsUp(true)
    setTimeout(() => setShowThumbsUp(false), 2000)

    // In a real app, this would send the commendation to a backend
    // For now, we'll just update the local state
    setStrangerReputation((prev) => ({
      ...prev,
      points: prev.points + 10,
      positiveRatings: prev.positiveRatings + 1,
    }))

    // Show a notification
    addNotification("commend", `You commended ${strangerUsername} as "${commendation.type}"!`)

    // Show a message in the chat
    addMessage(
      `You commended ${strangerUsername} as "${commendation.type}"${commendation.message ? `: "${commendation.message}"` : ""}.`,
      "stranger",
      "System",
    )
  }

  // Handle kick vote
  const handleKickVote = (reason: string) => {
    console.log("Kick vote:", reason)

    // Show thumbs down animation
    setShowThumbsDown(true)
    setTimeout(() => setShowThumbsDown(false), 2000)

    // In a real app, this would send the kick vote to a backend
    // For now, we'll just update the local state
    setStrangerReputation((prev) => ({
      ...prev,
      negativeRatings: prev.negativeRatings + 1,
    }))

    // Show a notification
    addNotification("kick", `You reported ${strangerUsername} for "${reason}".`)

    // Show a message in the chat
    addMessage(
      `You reported ${strangerUsername} for "${reason}". Our moderators will review this report.`,
      "stranger",
      "System",
    )

    // Skip to next person
    skipToNext()
  }

  // Skip to next person
  const skipToNext = async () => {
    // First leave the current channel
    if (agoraClient) {
      await leaveChannel(agoraClient, localTracks)
    }

    // Logout from chat
    if (chatClient && chatGroupId) {
      await logoutFromChat(chatClient)
      setChatGroupId(null)
    }

    // Reset state
    setMessages([])
    setInviteFriendId(null)
    setErrorMessage(null)
    setHasStrangerVideo(false)
    setIsConnected(false)
    setIsConnecting(true)
    setIsSearchingForStranger(true)
    setRemoteUsers([])
    setShowUserProfile(false)

    // Show finding next message
    addMessage(`Finding next person in ${currentLobby} lobby...`, "stranger", "System")

    // Start a new chat
    await startChat()

    setPeopleSkipped((prev) => prev + 1)
  }

  // Generate random stranger info
  const generateRandomStranger = () => {
    const names = ["Alex", "Jordan", "Taylor", "Casey", "Riley", "Morgan", "Jamie", "Quinn"]
    const randomName = names[Math.floor(Math.random() * names.length)]
    const randomNum = Math.floor(Math.random() * names.length)
    setStrangerUsername(`${randomName}${randomNum}`)

    // Assign a random country to the stranger
    const randomCountry = COUNTRIES[Math.floor(Math.random() * COUNTRIES.length)]
    setStrangerCountry(randomCountry)

    // Generate random reputation
    setStrangerReputation({
      level: Math.floor(Math.random() * 5) + 1,
      points: Math.floor(Math.random() * 500) + 25,
      positiveRatings: Math.floor(Math.random() * 50) + 5,
      negativeRatings: Math.floor(Math.random() * 5),
      badges: [],
      interestGroupBans: [],
    })
  }

  // Start chat
  const startChat = async () => {
    // Hide the waiting screen to show the videos
    setShowWaitingScreen(false)
    setIsConnecting(true)
    setIsSearchingForStranger(true)

    try {
      // Use mock data instead of calling the API
      const mockMatchResult = {
        status: "matched",
        channelName: "mock-channel-" + Math.random().toString(36).substring(2, 9),
        userId: Math.floor(Math.random() * 10000).toString(),
      }

      console.log("Mock match result:", mockMatchResult)

      // We found a match immediately, join the channel
      await joinVideoChat(mockMatchResult.channelName, Number.parseInt(mockMatchResult.userId))
    } catch (error) {
      console.error("Error starting chat:", error)
      setIsConnecting(false)
      setIsSearchingForStranger(false)
      addMessage("Error connecting to chat. Please try again.", "stranger", "System")
    }
  }

  // Function to join a video chat
  const joinVideoChat = async (channelName: string, userId: number) => {
    try {
      if (!agoraClient) {
        throw new Error("Agora client not initialized")
      }

      // Mock token data instead of calling the API
      const mockTokenData = {
        token: "mock-token-" + Math.random().toString(36).substring(2, 15),
        uid: userId || Math.floor(Math.random() * 10000),
      }

      console.log("Mock token:", mockTokenData.token, "uid:", mockTokenData.uid)

      // Set channel name and user ID
      setChannelName(channelName)
      setUserId(mockTokenData.uid)

      // Generate random stranger info
      generateRandomStranger()

      // Update state
      setIsConnected(true)
      setIsConnecting(false)
      setIsSearchingForStranger(false)

      // Add a welcome message
      if (selectedInterest) {
        addMessage(
          `Connected! You're chatting with ${strangerUsername} in the ${currentLobby} lobby.`,
          "stranger",
          "System",
        )
      } else {
        addMessage(`Connected! You're chatting with ${strangerUsername} in the General lobby.`, "stranger", "System")
      }

      // Simulate stranger video after a delay
      setTimeout(() => {
        setHasStrangerVideo(true)
      }, 2000)
    } catch (error) {
      console.error("Error joining video chat:", error)
      setIsConnecting(false)
      setIsSearchingForStranger(false)
      addMessage("Error joining chat. Please try again.", "stranger", "System")
    }
  }

  // Stop the chat - MODIFIED to just stop searching but keep showing yourself
  const stopChat = async () => {
    // Clear any existing search timeout
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current)
      searchTimeoutRef.current = null
    }

    // Leave the channel
    if (agoraClient) {
      await leaveChannel(agoraClient, localTracks)
    }

    // Logout from chat
    if (chatClient && chatGroupId) {
      await logoutFromChat(chatClient)
      setChatGroupId(null)
    }

    // Update state
    setIsConnected(false)
    setIsSearchingForStranger(false)
    setHasStrangerVideo(false)
    setRemoteUsers([])
    addDebugLog("Chat stopped, but camera still active")

    // Show a message that we've stopped searching
    addMessage("Stopped searching. Click Start to begin looking for someone new.", "stranger", "System")
  }

  // Send a message
  const sendMessage = () => {
    if (messageInput.trim() && isConnected) {
      // Add the message to our local state
      addMessage(messageInput, "me", user?.username || "You")

      // Send the message via Agora Chat
      if (chatClient && chatGroupId) {
        sendChatMessage(chatClient, chatGroupId, messageInput).catch((error) => {
          console.error("Error sending chat message:", error)
          addMessage("Failed to send message. Please try again.", "stranger", "System")
        })
      }

      // Clear the input
      setMessageInput("")
    }
  }

  // Add a message to the chat
  const addMessage = (
    text: string,
    sender: "me" | "stranger",
    username?: string,
    isMusic?: boolean,
    isEmoji?: boolean,
    isMeme?: boolean,
    isImage?: boolean,
    musicData?: any,
    memeUrl?: string,
    imageUrl?: string,
  ) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      text,
      sender,
      timestamp: new Date(),
      username,
      isMusic,
      isEmoji,
      isMeme,
      isImage,
      musicData,
      memeUrl,
      imageUrl,
    }

    setMessages((prev) => [...prev, newMessage])

    // If on mobile and the message is from stranger, show notification
    if (isMobile && sender === "stranger" && username !== "System" && !showChat) {
      const notification: ChatNotificationType = {
        id: Date.now().toString(),
        message: text,
        sender: username || "Stranger",
      }
      setChatNotifications((prev) => [...prev, notification])
    }
  }

  // Change country
  const changeCountry = (country: (typeof COUNTRIES)[0]) => {
    setSelectedCountry(country)
    addDebugLog(`Country changed to: ${country.name}`)
    // In a real app, this would filter users by country
    skipToNext()
  }

  // Handle Enter key in chat input
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      sendMessage()
    }
  }

  const toggleFriendsList = () => {
    setShowFriendsList(!showFriendsList)
  }

  // Invite friend to chat
  const inviteFriend = async (friendId: string) => {
    const friend = friends.find((f) => f.id === friendId)
    if (!friend) return

    // Leave current channel
    setMessages([])
    setErrorMessage(null)

    // Join the friend channel
    setIsConnecting(true)
    setStrangerUsername(friend.name)
    setInviteFriendId(friendId)
    setShowWaitingScreen(true)
    setHasStrangerVideo(false)
    addDebugLog(`Inviting friend: ${friend.name}`)

    // Hide friends dropdown after clicking
    setShowFriends(false)
    setShowFriendsList(false)

    // Simulate friend receiving notification
    setTimeout(() => {
      setPendingFriendRequest({
        id: userId.toString(),
        name: user?.username || "You",
      })
    }, 1000)

    // Simulate connection
    setTimeout(() => {
      setIsConnected(true)
      setIsConnecting(false)
      setShowWaitingScreen(false)

      // Add welcome message
      addMessage(`Starting chat with ${friend.name}`, "stranger", "System")

      // Simulate friend video
      setTimeout(() => {
        setHasStrangerVideo(true)
      }, 1500)
    }, 2000)
  }

  // Call a friend
  const handleCallFriend = async (friendId: string) => {
    const friend = friends.find((f) => f.id === friendId)
    if (!friend) return

    // Leave current channel
    setMessages([])
    setErrorMessage(null)

    // Join the friend channel
    setIsConnecting(true)
    setStrangerUsername(friend.name)
    setInviteFriendId(friendId)
    setShowWaitingScreen(false)
    setHasStrangerVideo(false)
    addDebugLog(`Calling friend: ${friend.name}`)

    // Hide friends dropdown after clicking
    setShowFriends(false)
    setShowFriendsList(false)

    // Simulate friend receiving call
    setTimeout(() => {
      setPendingFriendRequest({
        id: userId.toString(),
        name: user?.username || "You",
      })
    }, 1000)

    // Simulate connection
    setTimeout(() => {
      setIsConnected(true)
      setIsConnecting(false)
      setShowWaitingScreen(false)

      // Add welcome message
      addMessage(`Voice call with ${friend.name} connected`, "stranger", "System")

      // Simulate friend video
      setTimeout(() => {
        setHasStrangerVideo(true)
      }, 1500)
    }, 2000)
  }

  // Handle friend request response
  const handleFriendRequestAccept = () => {
    addDebugLog("Friend request accepted")
    // In a real app, this would connect the users
    addMessage("Friend request accepted. You are now connected.", "stranger", "System")
  }

  const handleFriendRequestDecline = () => {
    addDebugLog("Friend request declined")
    // In a real app, this would notify the sender
    addMessage("Friend request declined.", "stranger", "System")
  }

  // Update the toggleMusicPanel function to show blurred content with VIP popup inside
  const toggleMusicPanel = () => {
    setShowMusicPanel(!showMusicPanel)

    if (!isPlayingMusic && showMusicPanel) {
      setIsPlayingMusic(true)
      addMessage("Music sharing is now enabled. Select a track to play.", "stranger", "System")
    }
  }

  const connectToSpotify = async () => {
    // In a real implementation, this would redirect to Spotify OAuth
    // For now, we'll simulate a successful connection
    const fakeToken = "simulated-spotify-token-" + Math.random().toString(36).substring(2, 15)

    setSpotifyToken(fakeToken)

    // Load some fake playlists
    setSpotifyPlaylists([
      {
        id: "1",
        name: "My Favorites",
        image: "https://i.scdn.co/image/ab67616d0000b273c5649add07ed3720be9d5526",
        tracks: 24,
      },
      {
        id: "2",
        name: "Chill Vibes",
        image: "https://i.scdn.co/image/ab67616d0000b273c6f7af36eccd256b4d13cdee",
        tracks: 18,
      },
      {
        id: "3",
        name: "Workout Mix",
        image: "https://i.scdn.co/image/ab67616d0000b273da5d5aeeabacacc1263c0f4b",
        tracks: 32,
      },
    ])

    addDebugLog("Connected to Spotify")
  }

  const searchSpotify = (query: string) => {
    if (!query.trim()) {
      setSpotifySearchResults([])
      return
    }

    // Simulate search results
    const results = SAMPLE_TRACKS.filter(
      (track) =>
        track.title.toLowerCase().includes(query.toLowerCase()) ||
        track.artist.toLowerCase().includes(query.toLowerCase()),
    )

    setSpotifySearchResults(results)
    addDebugLog(`Searched Spotify for: ${query}`)
  }

  const playSpotifyTrack = (track: any) => {
    // Check if user has free songs remaining or is VIP
    if (!user?.isVIP && freeSongsRemaining <= 0) {
      setIsVipPopupOpen(true)
      return
    }

    // Play the track
    playTrack(track)

    // Decrement free songs if not VIP
    if (!user?.isVIP) {
      setFreeSongsRemaining((prev) => prev - 1)

      // Store in localStorage to persist between sessions
      localStorage.setItem("freeSongsRemaining", String(freeSongsRemaining - 1))
      localStorage.setItem("freeSongsResetDate", new Date().toISOString())
    }
  }

  // Handle file selection
  const handleFileSelect = (file: File, preview: string) => {
    if (isConnected) {
      addMessage("", "me", user?.username || "You", false, false, false, true, undefined, undefined, preview)

      // Simulate a response
      setTimeout(() => {
        addMessage("Nice pic! 👍", "stranger", strangerUsername)
      }, 1500)
    }
  }

  // Send friend request
  const sendFriendRequest = (username: string) => {
    if (!user) {
      // Prompt to login
      addMessage("Please sign in to add friends", "stranger", "System")
      setIsLoginModalOpen(true)
      return
    }

    // In a real app, this would send an API request
    console.log(`Friend request sent to ${username}`)
    addDebugLog(`Friend request sent to: ${username}`)

    // Show a temporary notification
    addMessage(`Friend request sent to ${username}`, "stranger", "System")

    // For demo purposes, add them to friends list after a delay
    setTimeout(() => {
      const newFriend = {
        id: Date.now().toString(),
        name: username,
        online: true,
      }

      const updatedFriends = [...friends, newFriend]
      setFriends(updatedFriends)
      localStorage.setItem("friends", JSON.stringify(updatedFriends))
    }, 2000)
  }

  // Share social media
  const shareSocialMedia = (platform: string) => {
    if (!user) return

    let username = ""
    let platformName = ""

    switch (platform) {
      case "instagram":
        username = user.instagram || ""
        platformName = "Instagram"
        break
      case "snapchat":
        username = user.snapchat || ""
        platformName = "Snapchat"
        break
      case "facebook":
        username = user.facebook || ""
        platformName = "Facebook"
        break
      case "discord":
        username = user.discord || ""
        platformName = "Discord"
        break
      default:
        return
    }

    if (!username) return

    // Add message to chat
    addMessage(`My ${platformName}: ${username}`, "me", user.username || "You")
  }

  // Handle login
  const handleLoginSuccess = (userData: UserType) => {
    // Initialize reputation if not present
    if (!userData.reputation) {
      userData.reputation = userReputation
    }

    localStorage.setItem("user", JSON.stringify(userData))
    setUser(userData)
    setIsLoggedIn(true)
    setUserReputation(userData.reputation)

    // Load friends from localStorage or create default if not exists
    const storedFriends = localStorage.getItem("friends")
    if (!storedFriends) {
      // Default friends for demo
      const defaultFriends = [
        { id: "1", name: "Alex123", online: true },
        { id: "2", name: "Jordan456", online: false },
        { id: "3", name: "Taylor789", online: true },
        { id: "4", name: "Riley42", online: true },
      ]
      setFriends(defaultFriends)
      localStorage.setItem("friends", JSON.stringify(defaultFriends))
    }

    addDebugLog(`User logged in: ${userData.username}`)
  }

  // Handle profile update
  const handleProfileUpdate = (userData: UserType) => {
    localStorage.setItem("user", JSON.stringify(userData))
    setUser(userData)
    setUserReputation(userData.reputation || userReputation)
    addDebugLog(`Profile updated for: ${userData.username}`)
  }

  // Handle logout
  const handleLogoutSuccess = () => {
    localStorage.removeItem("user")
    setUser(null)
    setIsLoggedIn(false)
    setIsSidebarOpen(false)
    addDebugLog("User logged out")
  }

  const handleSubscribe = () => {
    const updatedUser = {
      ...user,
      isVIP: true,
      subscriptionDate: new Date().toISOString(),
    }
    localStorage.setItem("user", JSON.stringify(updatedUser))
    setUser(updatedUser)
    setIsVipPopupOpen(false)
    setIsVip(true)
  }

  // Remove chat notification
  const removeChatNotification = (id: string) => {
    setChatNotifications((prev) => prev.filter((notification) => notification.id !== id))
  }

  // Handle country selection - VIP feature
  const handleCountrySelect = () => {
    setShowCountrySelector(true)
  }

  const handleEmojiMemeSelect = (value: string, isEmoji?: boolean, isMeme?: boolean) => {
    if (isConnected) {
      if (isEmoji) {
        addMessage(value, "me", user?.username || "You", false, true, false)
      } else if (isMeme) {
        addMessage("", "me", user?.username || "You", false, true, false)
      } else if (isMeme) {
        addMessage("", "me", user?.username || "You", false, false, true, false, undefined, value)
      }
    }
  }

  const playTrack = (track: any) => {
    if (audioRef.current) {
      audioRef.current.src = track.url
      audioRef.current.play()
      setIsAudioPlaying(true)
      setCurrentTrack(track)
      addMessage(`Now playing: ${track.title} by ${track.artist}`, "stranger", "System", true, false, false, false, {
        title: track.title,
        artist: track.artist,
        albumArt: track.albumArt,
      })
    }
  }

  const togglePlayPause = () => {
    if (audioRef.current) {
      if (isAudioPlaying) {
        audioRef.current.pause()
        setIsAudioPlaying(false)
      } else {
        audioRef.current.play()
        setIsAudioPlaying(true)
      }
    }
  }

  const playNextTrack = () => {
    if (currentTrack) {
      const currentIndex = SAMPLE_TRACKS.findIndex((track) => track.id === currentTrack.id)
      const nextIndex = (currentIndex + 1) % SAMPLE_TRACKS.length
      playTrack(SAMPLE_TRACKS[nextIndex])
    }
  }

  const playPrevTrack = () => {
    if (currentTrack) {
      const currentIndex = SAMPLE_TRACKS.findIndex((track) => track.id === currentTrack.id)
      const prevIndex = (currentIndex - 1 + SAMPLE_TRACKS.length) % SAMPLE_TRACKS.length
      playTrack(SAMPLE_TRACKS[prevIndex])
    }
  }

  const handleStartChat = () => {
    // Ensure camera is initialized
    const isLocal = true
    if (isLocal && videoRef.current) {
      navigator.mediaDevices
        .getUserMedia({ video: true, audio: true })
        .then((stream) => {
          if (videoRef.current) {
            videoRef.current.srcObject = stream
          }
        })
        .catch((err) => {
          console.error("Error accessing camera:", err)
          addDebugLog(`Camera error: ${err.message}`)
        })
    }

    // Start the chat
    startChat()
  }

  const handleStopChat = () => {
    stopChat()
  }

  const toggleMusic = () => {
    if (!isLoggedIn) {
      setIsLoginModalOpen(true)
      return
    }

    if (!isVip && musicUsageCount >= 5) {
      setIsVipPopupOpen(true)
      return
    }

    if (!isVip) {
      setMusicUsageCount((prev) => prev + 1)
    }

    // Always show the music player modal
    setShowMusicPlayer(true)
  }

  const callFriend = (friend: Friend) => {
    if (!isLoggedIn) {
      setIsLoginModalOpen(true)
      return
    }

    // Close the friends list
    setShowFriendsList(false)

    // Connect to the friend
    handleCallFriend(friend.id)
  }

  // Show interest selector
  const openInterestSelector = () => {
    setShowInterestSelector(true)
    setShowLobby(false)
  }

  // Handle dating list actions
  const handleMessageDatingProfile = (id: string) => {
    setShowDatingList(false)
    // Find the dating match
    const match = datingMatches.find((m) => m.id === id)
    if (!match) return

    // Simulate starting a chat with this person
    inviteFriend(match.id)
  }

  const handleCallDatingProfile = (id: string) => {
    setShowDatingList(false)
    // Find the dating match
    const match = datingMatches.find((m) => m.id === id)
    if (!match) return

    // Simulate calling this person
    handleCallFriend(match.id)
  }

  // Loading screen
  if (isLoading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-black">
        <div className="mb-8 flex items-center justify-center">
          <Image
            src="/images/logo.png"
            alt="ChatChill Logo"
            width={500}
            height={250}
            className={isMobile ? "w-64" : "w-96"}
          />
        </div>
        <Loader2 className="h-12 w-12 animate-spin text-yellow-500" />
      </div>
    )
  }

  // Function to render the local video
  const renderLocalVideo = () => {
    return (
      <CameraView
        isLocal={true}
        username={user?.username || "You"}
        countryFlag={selectedCountry.flag}
        isActive={true}
        profileImage={user?.profileImage}
        videoTrack={localTracks.videoTrack}
        audioTrack={localTracks.audioTrack}
      />
    )
  }

  // Function to render the remote video
  const renderRemoteVideo = () => {
    // Find the first remote user with a video track
    const remoteUser = remoteUsers.find((user) => user.videoTrack)
    const isDatingMode = currentLobby === "Speed Dating"

    return (
      <div className="relative h-full">
        <CameraView
          isLocal={false}
          username={strangerUsername}
          countryFlag={strangerCountry.flag}
          isActive={hasStrangerVideo && isConnected}
          videoTrack={remoteUser?.videoTrack}
          audioTrack={remoteUser?.audioTrack}
          onProfileClick={() => setShowUserProfile(true)}
        />

        {/* Dating Mode Overlay */}
        {isDatingMode && <DatingModeOverlay isVIP={isVip} />}

        {isConnected && hasStrangerVideo && (
          <VideoOverlayActions
            onThumbsUp={handleDirectThumbsUp}
            onThumbsDown={handleDirectThumbsDown}
            onViewProfile={() => setShowUserProfile(true)}
            onSuperLike={isDatingMode ? handleSuperLike : undefined}
            onUpgrade={() => setIsVipPopupOpen(true)}
            onUseFreeSuper={handleUseFreeSuper}
            username={strangerUsername}
            isVIP={isVip}
            freeSuperLikes={freeSuperLikes}
            isDatingMode={isDatingMode}
          />
        )}

        {/* Thumbs animations */}
        {showThumbsUp && <ThumbsAnimation type="up" />}
        {showThumbsDown && <ThumbsAnimation type="down" />}

        {/* Heart animation for super likes */}
        {showHeartAnimation && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="animate-ping text-pink-500 opacity-75" style={{ fontSize: "150px" }}>
              ❤️
            </div>
          </div>
        )}
      </div>
    )
  }

  // Wrap the main content with the DatingThemeProvider
  return (
    <DatingThemeProvider isDatingMode={currentLobby === "Speed Dating"}>
      <div className="flex h-screen bg-black text-white overflow-hidden">
        <style jsx global>{`
          @keyframes slide-in-left {
            from { transform: translateX(-100%); }
            to { transform: translateX(0); }
          }
          .animate-slide-in-left {
            animation: slide-in-left 0.3s ease-out forwards;
          }

          .no-outline-button {
            border: none;
            outline: none;
            box-shadow: none;
          }
        `}</style>

        {/* Fixed logo in top left corner - only visible on desktop */}
        {!isMobile && (
          <div className="fixed top-4 left-4 z-50">
            <Image
              src="/images/logo.png"
              alt="ChatChill Logo"
              width={240}
              height={96}
              className="h-32 w-auto"
              priority
            />
          </div>
        )}

        {/* Fixed header with menu buttons - MOBILE ONLY */}
        {isMobile && (
          <div className="fixed top-0 left-0 right-0 z-30 flex items-center justify-between p-2 bg-black/50 backdrop-blur-sm">
            <div className="flex items-center">
              <Image src="/images/logo.png" alt="ChatChill Logo" width={200} height={80} className="h-24 w-auto" />
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                className="h-10 w-10 rounded-full bg-black/30 hover:bg-black/50 border-0"
                onClick={() => setShowChat(!showChat)}
              >
                <MessageSquare className="h-5 w-5 text-white" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className={`h-10 w-10 rounded-full border-0 ${user?.isVIP ? "bg-yellow-500 text-black" : "bg-black/30 hover:bg-black/50"}`}
                onClick={() => setIsVipPopupOpen(true)}
              >
                <Crown className={`h-5 w-5 ${user?.isVIP ? "text-black" : "text-yellow-500"}`} />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-10 w-10 rounded-full bg-black/30 hover:bg-black/50 border-0"
                onClick={() => setIsSidebarOpen(true)}
              >
                <Menu className="h-5 w-5 text-white" />
              </Button>
            </div>
          </div>
        )}

        {/* Main content area - videos and chat */}
        <div className="flex flex-1">
          {/* Videos container - left side */}
          <div className={`flex flex-col ${isMobile ? "w-full pt-14" : showChat ? "w-[calc(100%-320px)]" : "w-full"}`}>
            {/* Videos row - column on mobile */}
            <div className="flex flex-col md:flex-row flex-1">
              {/* Stranger video - top on mobile, left on desktop */}
              <div className="relative w-full md:w-1/2 h-1/2 md:h-full bg-black">
                {showWaitingScreen ? (
                  <div className="flex h-full flex-col items-center justify-center p-4">
                    <div className="flex items-center gap-3 text-green-500 mb-8">
                      <div className="h-3 w-3 rounded-full bg-green-500 animate-pulse"></div>
                      <p className="text-xl font-medium">{onlineUsers.toLocaleString()} users online</p>
                    </div>
                    {!user ? (
                      <div className="flex flex-col items-center gap-4 mb-8">
                        <Button
                          className="bg-yellow-500 text-black hover:bg-yellow-600 px-8 max-w-[200px]"
                          onClick={() => setIsLoginModalOpen(true)}
                        >
                          Sign In / Create Account
                        </Button>
                        <div className="flex flex-col sm:flex-row gap-4">
                          <a href="#" className="inline-block h-12" aria-label="Download on the App Store">
                            <div className="flex items-center justify-center h-full px-4 py-2 bg-black text-white rounded-lg border border-gray-700">
                              <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" className="mr-2">
                                <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.19 2.33-.89 3.55-.77 1.5.16 2.63.77 3.38 1.95-3.03 1.72-2.39 5.8.84 6.75-.61 1.62-1.42 3.26-2.85 4.24zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.26 2.01-1.76 4.04-3.74 4.25z" />
                              </svg>
                              <span>App Store</span>
                            </div>
                          </a>
                          <a href="#" className="inline-block h-12" aria-label="Get it on Google Play">
                            <div className="flex items-center justify-center h-full px-4 py-2 bg-black text-white rounded-lg border border-gray-700">
                              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" className="mr-2">
                                <path d="M3.609 1.814L13.792 12 3.609 22.186c-.181.181-.29.435-.29.71 0 .544.46 1.004 1.004 1.004.275 0 .529-.109.71-.29l10.8-10.8c.181-.181.29-.435.29-.71s-.109-.529-.29-.71l-10.8-10.8c-.181-.181-.435-.29-.71-.29-.544 0-1.004.46-1.004 1.004 0 .275.109.529.29.71z" />
                              </svg>
                              <span>Google Play</span>
                            </div>
                          </a>
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-4 mb-8">
                        {!user.isVIP && (
                          <Button
                            onClick={() => setIsVipPopupOpen(true)}
                            className="bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-600 hover:to-amber-600 text-black font-medium"
                          >
                            <Sparkles className="mr-2 h-4 w-4" />
                            Upgrade to VIP
                          </Button>
                        )}
                      </div>
                    )}

                    {/* Interest selection button */}
                    <Button
                      onClick={openInterestSelector}
                      className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white"
                    >
                      <Compass className="mr-2 h-5 w-5" />
                      Find People by Interest
                    </Button>
                  </div>
                ) : (
                  <div className="relative h-full">
                    {/* Searching overlay */}
                    {isSearchingForStranger && (
                      <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-black/70 backdrop-blur-sm">
                        <Loader2 className="h-12 w-12 animate-spin text-yellow-500 mb-4" />
                        <p className="text-xl font-medium text-white mb-2">
                          Finding next person in {currentLobby} lobby...
                        </p>
                        <p className="text-gray-400 mb-4">This may take a moment</p>
                        <Button variant="outline" onClick={stopChat}>
                          Cancel
                        </Button>
                      </div>
                    )}
                    {renderRemoteVideo()}
                  </div>
                )}

                {isConnected && (
                  <div className="absolute bottom-4 left-4 text-sm text-gray-400">Click to end the current chat</div>
                )}
              </div>

              {/* User video - bottom on mobile, right on desktop */}
              <div className="relative w-full md:w-1/2 h-1/2 md:h-full bg-black">
                {renderLocalVideo()}

                {/* Top menu buttons - DESKTOP ONLY */}
                {!isMobile && (
                  <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
                    <button
                      className="h-10 w-10 rounded-full bg-black/50 backdrop-blur-sm text-white flex items-center justify-center"
                      style={{ border: "none", outline: "none", boxShadow: "none" }}
                      onClick={() => setShowChat(!showChat)}
                    >
                      <MessageSquare className="h-5 w-5" />
                    </button>
                    <button
                      className={`h-10 w-10 rounded-full ${user?.isVIP ? "bg-yellow-500 text-black" : "bg-black/50 backdrop-blur-sm text-white"} flex items-center justify-center`}
                      style={{ border: "none", outline: "none", boxShadow: "none" }}
                      onClick={() => setIsVipPopupOpen(true)}
                    >
                      <Crown className={`h-5 w-5 ${user?.isVIP ? "text-black" : "text-yellow-500"}`} />
                    </button>
                    <button
                      className="h-10 w-10 rounded-full bg-black/50 backdrop-blur-sm text-white flex items-center justify-center"
                      style={{ border: "none", outline: "none", boxShadow: "none" }}
                      onClick={() => setIsSidebarOpen(true)}
                    >
                      <Menu className="h-5 w-5" />
                    </button>
                  </div>
                )}

                {/* Current lobby indicator - clickable */}
                <button
                  onClick={openInterestSelector}
                  className="absolute top-4 left-4 z-20 bg-black/50 hover:bg-black/70 backdrop-blur-sm px-3 py-1.5 rounded-full transition-colors"
                >
                  <div className="flex items-center gap-2">
                    {currentLobby === "General" && <Compass className="h-4 w-4 text-blue-400" />}
                    {currentLobby === "Gaming" && <Gamepad2 className="h-4 w-4 text-green-400" />}
                    {currentLobby === "Music" && <Music className="h-4 w-4 text-purple-400" />}
                    {currentLobby === "Movies" && <Film className="h-4 w-4 text-red-400" />}
                    {currentLobby === "Sports" && <Trophy className="h-4 w-4 text-yellow-400" />}
                    {currentLobby === "Tech" && <Cpu className="h-4 w-4 text-cyan-400" />}
                    {currentLobby === "Art" && <Palette className="h-4 w-4 text-orange-400" />}
                    {currentLobby === "Speed Dating" && <Heart className="h-4 w-4 text-pink-500" />}
                    <span className="text-sm font-medium">{currentLobby} Lobby</span>
                  </div>
                </button>

                {/* User level indicator */}
                {user?.reputation && (
                  <div className="absolute bottom-4 right-4 z-20">
                    <ReputationDisplay
                      reputation={user.reputation}
                      size="sm"
                      className="bg-black/50 backdrop-blur-sm px-3 py-1.5 rounded-full"
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Bottom controls - always visible */}
            <div className="bg-gray-900 border-t border-gray-800 sticky bottom-0 left-0 right-0 z-10">
              <div className="grid grid-cols-2 gap-2 p-2">
                <Button
                  variant="default"
                  className={`h-12 ${currentLobby === "Speed Dating" ? "bg-pink-500 hover:bg-pink-600" : "bg-green-500 hover:bg-green-600"} flex items-center justify-center`}
                  onClick={showWaitingScreen ? handleStartChat : skipToNext}
                  disabled={isConnecting}
                >
                  {isConnecting ? (
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  ) : (
                    <SkipForward className="mr-2 h-5 w-5" />
                  )}
                  {showWaitingScreen ? "Start" : "Next"}
                </Button>
                <Button
                  variant="default"
                  className="h-12 bg-red-500 hover:bg-red-600 flex items-center justify-center"
                  onClick={handleStopChat}
                >
                  Stop
                </Button>

                <Button
                  variant="outline"
                  className={`h-12 bg-gray-800 hover:bg-gray-700 flex items-center justify-center text-white ${isMobile ? "border-0" : ""}`}
                  onClick={handleCountrySelect}
                >
                  <span className="text-xl mr-2">{selectedCountry.flag}</span>
                  <span>Country</span>
                  <ChevronDown className="ml-2 h-4 w-4" />
                </Button>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="outline"
                      className={`h-12 w-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center text-white ${isMobile ? "border-0" : ""}`}
                    >
                      {selectedGender === "male" ? (
                        <Male className="mr-2 h-5 w-5 text-blue-400" />
                      ) : selectedGender === "female" ? (
                        <Female className="mr-2 h-5 w-5 text-pink-400" />
                      ) : (
                        <Users2 className="mr-2 h-5 w-5 text-purple-400" />
                      )}
                      <span>I am</span>
                      <ChevronDown className="ml-2 h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-gray-800 border-gray-700 text-white">
                    <DropdownMenuItem
                      onClick={() => setSelectedGender("male")}
                      className="flex items-center gap-3 cursor-pointer hover:bg-gray-700"
                    >
                      <Male className="h-5 w-5 text-blue-400" />
                      <span>Male</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => setSelectedGender("female")}
                      className="flex items-center gap-3 cursor-pointer hover:bg-gray-700"
                    >
                      <Female className="h-5 w-5 text-pink-400" />
                      <span>Female</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => setSelectedGender("any")}
                      className="flex items-center gap-3 cursor-pointer hover:bg-gray-700"
                    >
                      <Users2 className="h-5 w-5 text-purple-400" />
                      <span>Any</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                <Button
                  variant={showFriendsList ? "default" : "outline"}
                  className={`h-12 ${showFriendsList ? "bg-blue-600 hover:bg-blue-700" : "bg-gray-800 hover:bg-gray-700"} flex items-center justify-center text-white ${isMobile ? "border-0" : ""}`}
                  onClick={toggleFriendsList}
                >
                  <Users className="mr-2 h-5 w-5" />
                  <span>Friends</span>
                  <span className="ml-2">
                    {showFriendsList ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  </span>
                </Button>

                <Button
                  variant={showMusicPlayer ? "default" : "outline"}
                  className={`h-12 w-full ${showMusicPlayer ? "bg-green-600 hover:bg-green-700" : "bg-gray-800 hover:bg-gray-700"} flex items-center justify-center text-white ${isMobile ? "border-0" : ""}`}
                  onClick={toggleMusic}
                >
                  <Music className="mr-2 h-5 w-5" />
                  <span>Music</span>
                  {user?.isVIP ? null : <span className="ml-1 text-xs text-gray-400">({freeSongsRemaining} free)</span>}
                </Button>
              </div>
            </div>
          </div>

          {/* Chat panel - right side for desktop, slide-in for mobile */}
          {!isMobile && showChat && (
            <div className="hidden md:flex md:flex-col w-80 bg-gray-800 border-gray-700 border-l">
              <div className="border-gray-700 border-b p-3 flex items-center justify-between">
                <h2 className="font-medium">
                  {isConnected ? `Speaking with ${strangerUsername}` : `Welcome, ${user?.username || "Guest"}`}
                </h2>
              </div>

              {/* Messages */}
              <div ref={chatContainerRef} className="flex-1 overflow-y-auto p-3">
                {messages.length === 0 ? (
                  <div className="flex h-full items-center justify-center">
                    <p className="text-center text-sm">
                      {isConnected ? "No messages yet. Say hello!" : "Connect with someone to start chatting"}
                    </p>
                  </div>
                ) : (
                  <div className="flex flex-col gap-3">
                    {messages.map((message) => (
                      <div key={message.id} className="flex flex-col">
                        {message.sender === "stranger" && message.username !== "System" && (
                          <div className="mb-1 flex items-center gap-2">
                            <div className="h-8 w-8 overflow-hidden rounded-full bg-gray-700">
                              <div className="h-full w-full flex items-center justify-center text-white font-bold">
                                {message.username?.charAt(0).toUpperCase() || "S"}
                              </div>
                            </div>
                            <span className="text-sm font-medium">{message.username}</span>
                            {message.sender === "stranger" && message.username !== "System" && (
                              <Button
                                size="sm"
                                variant="outline"
                                className="ml-auto h-6 rounded-full bg-yellow-500 px-2 py-0 text-xs text-black hover:bg-yellow-600"
                                onClick={() => sendFriendRequest(message.username || "Unknown")}
                              >
                                +Invite
                              </Button>
                            )}
                          </div>
                        )}
                        <div
                          className={cn(
                            "max-w-[90%] rounded-lg p-2 text-sm",
                            message.sender === "me" ? "ml-auto bg-gray-700" : "bg-gray-700",
                            message.username === "System" ? "bg-gray-600 text-gray-300" : "",
                          )}
                        >
                          {message.isMusic && message.musicData ? (
                            <div className="flex flex-col">
                              <p className="mb-2">{message.text}</p>
                              <div className="flex items-center gap-2 bg-gray-800 p-2 rounded-md">
                                <img
                                  src={message.musicData.albumArt || "/placeholder.svg"}
                                  alt={message.musicData.title}
                                  className="h-10 w-10 rounded-md"
                                />
                                <div>
                                  <p className="font-medium text-xs">{message.musicData.title}</p>
                                  <p className="text-xs text-gray-400">{message.musicData.artist}</p>
                                </div>
                              </div>
                            </div>
                          ) : message.isEmoji ? (
                            <span className="text-2xl">{message.text}</span>
                          ) : message.isMeme ? (
                            <div className="w-full overflow-hidden rounded-md">
                              <img src={message.memeUrl || "/placeholder.svg"} alt="Meme" className="w-full h-auto" />
                            </div>
                          ) : message.isImage ? (
                            <div className="w-full overflow-hidden rounded-md">
                              <img
                                src={message.imageUrl || "/placeholder.svg"}
                                alt="Shared image"
                                className="w-full h-auto"
                              />
                            </div>
                          ) : (
                            message.text
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Message input */}
              <div className="border-t border-gray-700 p-3">
                <div className="flex items-center gap-2">
                  <Input
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Type a message..."
                    disabled={!isConnected}
                    className="bg-gray-700 border-gray-600 focus-visible:ring-gray-500 text-white"
                  />
                  <EmojiPicker onSelect={handleEmojiMemeSelect} />
                  <Button
                    variant="default"
                    size="icon"
                    className="h-10 w-10 bg-yellow-500 hover:bg-yellow-600 text-black"
                    onClick={sendMessage}
                    disabled={!isConnected || !messageInput.trim()}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-5 w-5"
                    >
                      <path d="m22 2-7 20-4-9-9-4Z" />
                      <path d="M22 2 11 13" />
                    </svg>
                    <span className="sr-only">Send</span>
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Interest Selector */}
          {showInterestSelector && (
            <InterestSelector onSelect={handleInterestSelect} onClose={() => setShowInterestSelector(false)} />
          )}

          {/* Lobby Room */}
          {showLobby && selectedInterest && (
            <LobbyRoom
              interest={selectedInterest}
              onStartChat={handleStartChat}
              onChangeInterest={openInterestSelector}
              onClose={() => setShowLobby(false)}
            />
          )}

          {/* User Profile Card */}
          {showUserProfile && (
            <UserProfileCard
              userId={`stranger-${Date.now()}`}
              username={strangerUsername}
              countryFlag={strangerCountry.flag}
              countryName={strangerCountry.name}
              reputation={strangerReputation}
              currentUserId={userId.toString()}
              onCommend={handleCommendation}
              onKickVote={handleKickVote}
              onClose={() => setShowUserProfile(false)}
            />
          )}

          {/* Notifications */}
          {notifications.map((notification) => (
            <CommendationNotification
              key={notification.id}
              type={notification.type}
              message={notification.message}
              onClose={() => removeNotification(notification.id)}
            />
          ))}

          {/* Friends List Modal */}
          <FriendsListModal
            friends={friends}
            isOpen={showFriendsList}
            onClose={() => setShowFriendsList(false)}
            onCallFriend={callFriend}
            onChatWithFriend={inviteFriend}
          />

          {/* Music Player Modal */}
          <MusicPlayerModal
            isOpen={showMusicPlayer}
            onClose={() => setShowMusicPlayer(false)}
            isVip={isVip}
            freeSongsRemaining={freeSongsRemaining}
            onVipUpgrade={() => setIsVipPopupOpen(true)}
            onSpotifyConnected={() => {
              addMessage("Successfully connected to Spotify! You can now play music.", "stranger", "System")
              setSpotifyConnected(true)
            }}
          />

          {/* Country Selector Modal */}
          <CountrySelectorModal
            isOpen={showCountrySelector}
            onClose={() => setShowCountrySelector(false)}
            selectedCountry={selectedCountry}
            onSelectCountry={changeCountry}
          />

          {/* Dating List Modal */}
          <DatingListModal
            isOpen={showDatingList}
            onClose={() => setShowDatingList(false)}
            onMessage={handleMessageDatingProfile}
            onCall={handleCallDatingProfile}
          />

          {/* Sidebar */}
          <Sidebar
            isOpen={isSidebarOpen}
            onClose={() => setIsSidebarOpen(false)}
            user={user}
            onLogout={handleLogoutSuccess}
            microphoneVolume={microphoneVolume}
            speakerVolume={speakerVolume}
            onMicrophoneVolumeChange={setMicrophoneVolume}
            onSpeakerVolumeChange={setSpeakerVolume}
            debugLogs={debugLogs}
            clearDebugLogs={clearDebugLogs}
            onEditProfile={() => setIsProfileModalOpen(true)}
            onOpenDatingList={() => setShowDatingList(true)}
          />

          {/* VIP Popup */}
          {isVipPopupOpen && (
            <VipPopup
              isOpen={true}
              onClose={() => setIsVipPopupOpen(false)}
              onSubscribe={handleSubscribe}
              isVIP={isVip}
              subscriptionDate={user?.subscriptionDate}
            />
          )}
        </div>
      </div>
    </DatingThemeProvider>
  )
}
