"use client"

import { useState } from "react"
import { HMSVideoCall } from "@/components/hms-video-call"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function HMSPage() {
  const [roomId, setRoomId] = useState("")
  const [username, setUsername] = useState("")
  const [isJoined, setIsJoined] = useState(false)

  const handleJoinRoom = () => {
    setIsJoined(true)
  }

  const handleLeaveRoom = () => {
    setIsJoined(false)
  }

  return (
    <div className="flex min-h-screen flex-col bg-black text-white">
      <header className="border-b border-gray-800 py-2 px-3">
        <div className="container mx-auto flex items-center">
          <Link href="/" className="flex items-center">
            <ArrowLeft className="mr-2 h-5 w-5" />
            <span>Back to Chat</span>
          </Link>
          <div className="mx-auto">
            <Image src="/images/logo.png" alt="ChatChill Logo" width={200} height={80} className="h-16 w-auto" />
          </div>
          <div className="w-24"></div> {/* Spacer for balance */}
        </div>
      </header>

      <main className="container mx-auto flex flex-1 flex-col p-4">
        {!isJoined ? (
          <div className="mx-auto flex w-full max-w-md flex-col items-center justify-center">
            <div className="mb-8 w-full rounded-lg border border-gray-800 bg-gray-900 p-6">
              <h1 className="mb-6 text-center text-2xl font-bold">Join 100ms Video Call</h1>

              <div className="mb-4">
                <label htmlFor="username" className="mb-2 block text-sm font-medium">
                  Your Name
                </label>
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter your name"
                  className="bg-gray-800 border-gray-700"
                  required
                />
              </div>

              <div className="mb-6">
                <label htmlFor="roomId" className="mb-2 block text-sm font-medium">
                  Room ID (Optional)
                </label>
                <Input
                  id="roomId"
                  value={roomId}
                  onChange={(e) => setRoomId(e.target.value)}
                  placeholder="Enter room ID or leave empty for random room"
                  className="bg-gray-800 border-gray-700"
                />
              </div>

              <Button
                onClick={handleJoinRoom}
                disabled={!username}
                className="w-full bg-yellow-500 text-black hover:bg-yellow-600"
              >
                Join Video Call
              </Button>
            </div>

            <p className="text-center text-sm text-gray-400">
              Powered by 100ms video API with template ID:{" "}
              {process.env.NEXT_PUBLIC_100MS_TEMPLATE_ID || "Not configured"}
            </p>
          </div>
        ) : (
          <div className="flex flex-1 flex-col">
            <h1 className="mb-4 text-xl font-bold">Video Call: {roomId || "Default Room"}</h1>
            <div className="flex-1 overflow-hidden rounded-lg border border-gray-800">
              <HMSVideoCall
                roomId={roomId}
                username={username}
                onJoinRoom={handleJoinRoom}
                onLeaveRoom={handleLeaveRoom}
              />
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
